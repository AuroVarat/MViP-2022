from matplotlib import pyplot
from main import main
import numpy as np
from tqdm import tqdm

# n = 1000

# sites = np.empty(n)
# for i in tqdm(range(n)):
#     sites[i] = main()

sites = np.genfromtxt("hist.dat")
pyplot.hist(sites,bins = 70,range=(0,np.nanmax(sites))) 
pyplot.show() 
#np.savetxt("Checkpoint_2/GOL/hist.dat", sites)