from matplotlib import pyplot as plt
from main import main
import numpy as np
from tqdm import tqdm

x = np.linspace(0,1,21)
#x = np.linspace(0.2,0.5,30)
XX,YY = np.meshgrid(x,x)
ai = np.genfromtxt("Checkpoint_2/SIRS/output-mean-immunized-dyeq.dat")
vi = np.genfromtxt("Checkpoint_2/SIRS/output-var.dat")

plt.errorbar(x,ai[:,0],yerr=ai[:,1],ecolor='red',fmt='--',alpha=0.5,capsize=3.0)

#plt.colorbar()
plt.show()

#plt.contourf(XX,YY,ai)
plt.imshow(ai,extent=[0,1,0,1],origin='lower')
plt.colorbar()
plt.show()

#plt.contourf(XX,YY,vi)
plt.imshow(vi,extent=[0,1,0,1],origin='lower')
plt.colorbar()
plt.show()